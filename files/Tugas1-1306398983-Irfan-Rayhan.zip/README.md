diffie-hellman
==============

Diffie-Hellman Key Exchange algorithm implementation on Javascript. Created for Discrete Mathematics 2 Assignment.
